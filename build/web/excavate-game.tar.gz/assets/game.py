import asyncio
import pygame
import constants as C
from world import World
from player import Player
from camera import Camera
from ui import UI
from tile import TileKind, get_zone_index
from touch_controls import TouchControls
import highscore as hs


class _KeysWithTouch:
    """Wraps pygame key state and overlays touch button state."""
    def __init__(self, keys, touch: TouchControls):
        self._keys = keys
        self._touch = touch

    def __getitem__(self, k):
        result = self._keys[k]
        if k in (pygame.K_LEFT, pygame.K_a):
            result = result or self._touch.is_held("left")
        elif k in (pygame.K_RIGHT, pygame.K_d):
            result = result or self._touch.is_held("right")
        return result


class GameState:
    START      = "start"
    PLAYING    = "playing"
    GAME_OVER  = "game_over"
    WIN        = "win"
    NAME_INPUT = "name_input"


class Game:
    def __init__(self):
        self.screen = pygame.display.get_surface()
        self.clock  = pygame.time.Clock()
        self.ui     = UI()
        self.ui.load_fonts()
        self.touch  = TouchControls()
        self.state  = GameState.START
        self.input_name: str = ""
        self._post_name_state: str = GameState.START
        self._new_game()

    def _toggle_fullscreen(self):
        is_fullscreen = bool(self.screen.get_flags() & pygame.FULLSCREEN)
        if is_fullscreen:
            self.screen = pygame.display.set_mode(
                (C.SCREEN_WIDTH, C.SCREEN_HEIGHT)
            )
        else:
            self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)

    def _new_game(self):
        import random
        self.world  = World(seed=random.randint(0, 99999))
        self.player = Player(self.world)
        self.camera = Camera()
        self.input_name = ""
        self._fluid_tick = 0

    # ------------------------------------------------------------------ #
    #  Haupt-Loop                                                          #
    # ------------------------------------------------------------------ #

    async def run(self):
        running = True
        while running:
            self.clock.tick(C.FPS)

            try:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False

                    # Any user interaction starts the game from the start screen
                    if self.state == GameState.START and event.type in (
                        pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP,
                        pygame.FINGERDOWN, pygame.FINGERUP,
                    ):
                        self.state = GameState.PLAYING

                    if event.type == pygame.KEYDOWN:
                        running = self._handle_keydown(event)
                    if event.type == pygame.TEXTINPUT:
                        if self.state == GameState.NAME_INPUT:
                            if len(self.input_name) < 12:
                                self.input_name += event.text
                    self.touch.handle_event(event)
                    self._handle_touch_nav(event)

                # One-shot touch actions (jump, dig)
                for action in self.touch.consume_just_pressed():
                    if self.state == GameState.PLAYING:
                        if action == "jump":
                            self.player.jump()
                        elif action == "dig_down":
                            self.player.try_dig("down")

                keys = _KeysWithTouch(pygame.key.get_pressed(), self.touch)
                self._update(keys)
                self._draw()
                pygame.display.flip()
            except Exception as e:
                import traceback
                print("GAME LOOP ERROR:", e)
                traceback.print_exc()
                # Don't kill the loop — keep running so the screen stays visible

            await asyncio.sleep(0)

    # ------------------------------------------------------------------ #
    #  Input                                                               #
    # ------------------------------------------------------------------ #

    def _handle_touch_nav(self, event):
        """Click/tap-to-start and tap-to-restart for pointer input."""
        if event.type not in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN):
            return
        if self.state == GameState.START:
            self.state = GameState.PLAYING
        elif self.state in (GameState.GAME_OVER, GameState.WIN):
            self.state = GameState.PLAYING
            self._new_game()

    def _handle_keydown(self, event) -> bool:
        key = event.key

        if key == pygame.K_ESCAPE:
            return False  # quit

        if key == pygame.K_F11:
            self._toggle_fullscreen()
            return True

        # --- Start Screen ---
        if self.state == GameState.START:
            if key in (pygame.K_RETURN, pygame.K_SPACE):
                self.state = GameState.PLAYING
            return True

        # --- Name Input ---
        if self.state == GameState.NAME_INPUT:
            if key == pygame.K_RETURN:
                name = self.input_name.strip() or "Anonym"
                hs.save(name, self.player.points)
                pygame.key.stop_text_input()
                self.state = self._post_name_state
            elif key == pygame.K_BACKSPACE:
                self.input_name = self.input_name[:-1]
            return True

        # --- Neustart ---
        if key == pygame.K_r:
            self.state = GameState.PLAYING
            self._new_game()
            return True

        if self.state != GameState.PLAYING:
            return True

        # --- Spielsteuerung ---
        if key in (pygame.K_UP, pygame.K_w, pygame.K_SPACE):
            self.player.jump()
        if key in (pygame.K_DOWN, pygame.K_s):
            self.player.try_dig("down")
        if key == pygame.K_q:
            self.player.try_dig("left")
        if key == pygame.K_e:
            self.player.try_dig("right")

        return True

    def _update(self, keys):
        if self.state != GameState.PLAYING:
            return

        # Welt horizontal und vertikal expandieren
        player_tx = self.player.rect.centerx // C.TILE_SIZE
        player_ty = self.player.rect.bottom  // C.TILE_SIZE
        self.world.ensure_around(player_tx)
        self.world.ensure_depth(player_ty)

        self.player.update(keys)
        self.camera.update(self.player.rect, self.world)

        # Fluid-Simulation alle 6 Frames
        self._fluid_tick += 1
        if self._fluid_tick >= 6:
            self._fluid_tick = 0
            self.world.tick_fluids()

        if not self.player.alive and self.state == GameState.PLAYING:
            if hs.is_highscore(self.player.points):
                self._post_name_state = GameState.GAME_OVER
                self.state = GameState.NAME_INPUT
                pygame.key.start_text_input()
            else:
                self.state = GameState.GAME_OVER

        if self.player.won and self.state == GameState.PLAYING:
            if hs.is_highscore(self.player.points):
                self._post_name_state = GameState.WIN
                self.state = GameState.NAME_INPUT
                pygame.key.start_text_input()
            else:
                self.state = GameState.WIN

    # ------------------------------------------------------------------ #
    #  Zeichnen                                                            #
    # ------------------------------------------------------------------ #

    def _draw(self):
        if self.state == GameState.START:
            self.ui.draw_start_screen(self.screen)
            return

        self.screen.fill(C.COLOR_SKY)
        self._draw_world()
        self._draw_player()
        self._draw_hud()
        if C.IS_WEB:
            self.touch.draw(self.screen)

        if self.state == GameState.GAME_OVER:
            self.ui.draw_game_over(self.screen, self.player.points)
        elif self.state == GameState.WIN:
            self.ui.draw_win(self.screen, self.player.points)
        elif self.state == GameState.NAME_INPUT:
            self.ui.draw_name_input(self.screen, self.input_name, self.player.points)

    def _draw_world(self):
        first_row, last_row = self.camera.visible_tile_range()
        first_col, last_col = self.camera.visible_col_range()

        for ty in range(first_row, last_row):
            screen_y = self.camera.world_to_screen_y(ty * C.TILE_SIZE)
            for tx in range(first_col, last_col):
                tile = self.world.get(tx, ty)
                if tile.kind == TileKind.AIR:
                    continue
                screen_x = self.camera.world_to_screen_x(tx * C.TILE_SIZE)
                rect = pygame.Rect(screen_x, screen_y, C.TILE_SIZE, C.TILE_SIZE)
                pygame.draw.rect(self.screen, tile.color, rect)
                pygame.draw.rect(self.screen, (0, 0, 0), rect, 1)

                if tile.kind in (TileKind.RESOURCE, TileKind.DIAMOND):
                    glow = pygame.Surface((C.TILE_SIZE - 6, C.TILE_SIZE - 6), pygame.SRCALPHA)
                    glow.fill((*tile.color[:3], 80))
                    inner = pygame.Rect(
                        screen_x + 3,
                        screen_y + 3,
                        C.TILE_SIZE - 6,
                        C.TILE_SIZE - 6,
                    )
                    self.screen.blit(glow, inner)

    def _draw_player(self):
        screen_rect = self.camera.apply(self.player.rect)
        pygame.draw.rect(self.screen, C.COLOR_PLAYER, screen_rect, border_radius=4)
        eye_y = screen_rect.top + 6
        pygame.draw.circle(self.screen, C.COLOR_BLACK, (screen_rect.left + 6, eye_y), 3)
        pygame.draw.circle(self.screen, C.COLOR_BLACK, (screen_rect.right - 6, eye_y), 3)
        # Name above player
        name_surf = self.ui.font_small.render(C.PLAYER_NAME, True, C.COLOR_WHITE)
        nx = screen_rect.centerx - name_surf.get_width() // 2
        self.screen.blit(name_surf, (nx, screen_rect.top - name_surf.get_height() - 1))

    def _draw_hud(self):
        self.ui.draw_hud(self.screen, self.player)
        depth = self.player.depth()
        zone_idx = get_zone_index(depth + 2)
        zone_name = C.ZONES[zone_idx]["name"]
        if depth >= C.ZONES[-1]["to"]:
            zone_name = f"{zone_name} (Tiefe {depth}m)"
        self.ui.draw_zone_name(self.screen, zone_name)
